<div id="breadcrumbs-wrapper" style="padding: 0 0;">
	<div class="container">
	  <div class="row">
		 <div class="col s10 m6 l6">
			<h5 class="breadcrumbs-title">DashBoard</h5>
			<ol class="breadcrumbs">
			  <li><a href="#" style="color: #00796b">Inicio</a></li> 
			</ol>
		 </div>               
	  </div>
	</div>
 </div>
<div class="container">
	<!--card stats start-->
	<div id="card-stats">
	  <div class="row"> 
		 <div class="col s12 m6 l4 offset-l1">
			<div class="card padding-4 animate fadeLeft">
				<div class="col s5 m5">
					<h5 class="mb-0">3</h5>
					<p class="no-margin">Ticecks</p>
					<p class="mb-0 pt-8"></p>
				</div>
				<div class="col s7 m7 right-align">
					<i class="material-icons background-round mt-5 mb-5 teal darken-1 gradient-shadow white-text">note</i>
					<p class="mb-0">Proformas Generadas </p>
				</div>
			</div>
		 </div> 
	  </div> 
	</div>
 
</div>
<br><br>