<div class="row center-align hide">
                            <div class="col s12 m4 l4">
                                <div class="card">
                                    <div class="card-content indigo white-text" style="padding: 10px">
                                        <p class="card-stats-title"><i class="mdi-editor-attach-money"></i>Total Ingresos</p>
                                        <h5 class="card-stats-number white-text" style="margin-top: 0px; margin-bottom: 0px">$560.00</h5>
                                        <p class="card-stats-compare"><i class="mdi-hardware-keyboard-arrow-up"></i> 40% <span class="indigo-text text-lighten-5">ultimo mes</span>
                                        </p>
                                    </div>
                                    <div class="card-action indigo darken-2" style="padding: 10px">
                                        <div id="sales-compositebar" class="center-align"><canvas width="214" height="25" style="display: inline-block; width: 214px; height: 25px; vertical-align: top;"></canvas></div>

                                    </div>
                                </div>
                            </div>                            
                            <div class="col s12 m4 l4">
                                <div class="card">
                                    <div class="card-content blue-grey white-text" style="padding: 10px">
                                        <p class="card-stats-title"><i class="mdi-action-trending-up"></i>Transacciones hoy</p>
                                        <h5 class="card-stats-number white-text" style="margin-top: 0px; margin-bottom: 0px">$70.00</h5>
                                        <p class="card-stats-compare"><i class="mdi-hardware-keyboard-arrow-up"></i> 10% <span class="blue-grey-text text-lighten-5">de ultima semana</span>
                                        </p>
                                    </div>
                                    <div class="card-action blue-grey darken-2" style="padding: 10px">
                                        <div id="profit-tristate" class="center-align"><canvas width="227" height="25" style="display: inline-block; width: 227px; height: 25px; vertical-align: top;"></canvas></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col s12 m4 l4">
                                <div class="card">
                                    <div class="card-content teal lighten-2 white-text" style="padding: 10px">
                                        <p class="card-stats-title"><i class="mdi-editor-insert-drive-file"></i>Facturas pendientes</p>
                                        <h5 class="card-stats-number white-text" style="margin-top: 0px; margin-bottom: 0px">6</h5>
                                        <p class="card-stats-compare"><i class="mdi-hardware-keyboard-arrow-down"></i> 18% <span class="teal-text text-lighten-5">este mes</span>
                                        </p>
                                    </div>
                                    <div class="card-action  teal darken-1" style="padding: 10px">
                                        <div id="invoice-line" class="center-align"><canvas width="265" height="25" style="display: inline-block; width: 265px; height: 25px; vertical-align: top;"></canvas></div>
                                    </div>
                                </div>
                            </div>        
                        </div>