{{-- Acreditación de lengua nativa  --}}
<div class="col s12 m6 l12">
	<br>
	<div class="card">
		<div class="row">
			<div class="col s12 m12 l12">
				<div class="card-content" style="overflow-x:scroll">
					<table id="data-table-simpleII" class="responsive-table display tabla" style="white-space: nowrap;">
						<thead>
							<tr>
								<th>#</th>
								<th>IDIOMA</th>
								<th>DOMINIO ESCRITURA</th>
								<th>DOMINIO ORAL</th>
								<th>F.EMISIÓN'</th>
								<th>AÑO DE VIGENCIA</th> 
							</tr>
						</thead>
						<tfoot>
							<tr>
								<th>#</th>
								<th>IDIOMA</th>
								<th>DOMINIO ESCRITURA</th>
								<th>DOMINIO ORAL</th>
								<th>F.EMISIÓN'</th>
								<th>AÑO DE VIGENCIA</th> 
							</tr>
						</tfoot>
						<tbody>
							<tr>
								<td>1</td>
								<td>ESPAÑOL</td>
								<td>AVANZADO</td>
								<td>AVANZADO</td>
								<td>21-09-2019</td>
								<td> 5</td> 
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
{{-- Acreditación de lengua nativa  --}}