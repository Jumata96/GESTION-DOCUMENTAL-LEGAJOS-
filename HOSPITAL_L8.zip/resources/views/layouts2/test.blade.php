@extends('layouts2.app')
@section('titulo','DashBoard')

@section('main-content')
<div class="card">
        <div class="card-content">
            <p class="caption mb-0">
                Sample blank page for getting start!! Created and designed by Google, Material Design is a design
                language that combines the classic principles of successful design along with innovation and
                technology.
            </p>
        </div>
    </div>
  
@endsection

